package com.example.zomaggyapiseroproject;

import java.sql.SQLException;

public interface ZomaggyDAOUpdateInterface {

    public int updateDAOProfile(ZomaggyEntity ze) throws SQLException;
}
