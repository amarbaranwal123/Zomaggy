package com.example.zomaggyapiseroproject;

import java.sql.SQLException;

public interface ZomaggyDAODeeleteInterface {

    public boolean deleteDAOProfile(ZomaggyEntity ze) throws SQLException;
}
