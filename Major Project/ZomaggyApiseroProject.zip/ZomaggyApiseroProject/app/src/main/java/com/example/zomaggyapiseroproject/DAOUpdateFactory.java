package com.example.zomaggyapiseroproject;

public class DAOUpdateFactory {

    public static ZomaggyDAOUpdateInterface createDAOObject(){


        return  new ZomaggyDAOUpdate();
    }
}
