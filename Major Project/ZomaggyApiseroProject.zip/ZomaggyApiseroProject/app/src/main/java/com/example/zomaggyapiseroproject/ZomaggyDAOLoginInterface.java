package com.example.zomaggyapiseroproject;

import java.sql.SQLException;

public interface ZomaggyDAOLoginInterface {


    public boolean loginDAOProfile1(ZomaggyEntity ze) throws SQLException;
}
