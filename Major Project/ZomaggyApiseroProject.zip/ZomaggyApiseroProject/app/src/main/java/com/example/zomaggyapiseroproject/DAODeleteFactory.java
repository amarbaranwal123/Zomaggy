package com.example.zomaggyapiseroproject;

public class DAODeleteFactory {

    public static ZomaggyDAODeeleteInterface createDAOObject(){


        return new ZomaggyDAODelete();
    }
}
