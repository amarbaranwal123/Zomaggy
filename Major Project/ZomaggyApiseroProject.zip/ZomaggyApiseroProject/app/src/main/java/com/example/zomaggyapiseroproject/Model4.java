package com.example.zomaggyapiseroproject;

public class Model4 {

    String resname;

    public Model4(String resname) {
        this.resname = resname;
    }


    public String getResname() {
        return resname;
    }

    public void setResname(String resname) {
        this.resname = resname;
    }
}
